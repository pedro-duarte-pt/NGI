/*****************************************************************************
 *
 * Microchip CANopen Stack (Device Info)
 *
 *****************************************************************************
 * FileName:        CO_DEV.C
 * Dependencies:    
 * Processor:       PIC18F with CAN
 * Compiler:       	C18 02.30.00 or higher
 * Linker:          MPLINK 03.70.00 or higher
 * Company:         Microchip Technology Incorporated
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the "Company") is intended and supplied to you, the Company's
 * customer, for use solely and exclusively with products manufactured
 * by the Company. 
 *
 * The software is owned by the Company and/or its supplier, and is 
 * protected under applicable copyright laws. All rights are reserved. 
 * Any use in violation of the foregoing restrictions may subject the 
 * user to criminal sanctions under applicable laws, as well as to 
 * civil liability for the breach of the terms and conditions of this 
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES, 
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT, 
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR 
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *
 * This file contains many of the standard objects defined by CANopen.
 * 
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ross Fosler			11/13/03	...	
 * 
 *****************************************************************************/

#include	"CO_TYPES.H"


// CANopen object 0x1000
const unsigned long rCO_DevType = 			0x0L;   //non standard device

// CANopen object 0x1008
const unsigned char rCO_DevName[] = 			"NGI HONDA OBD1 ECU BRIDGE";

// CANopen object 0x1009
const unsigned char rCO_DevHardwareVer[] = 	"V1.0";

// CANopen object 0x100A
const unsigned char rCO_DevSoftwareVer[] = 	"V1.0";

// CANopen object 0x1018
const unsigned char rCO_DevIdentityIndx = 	0x4;
const unsigned long rCO_DevVendorID = 		0x11223344L;    //dummy vendor ID
const unsigned long rCO_DevProductCode = 	0x00000001L;
const unsigned long rCO_DevRevNo = 			0x00000001L;
const unsigned long rCO_DevSerialNo = 		0x00000001L;

// CANopen object 0x1001
unsigned char uCO_DevErrReg;

// CANopen object 0x1002
unsigned long uCO_DevManufacturerStatReg;

